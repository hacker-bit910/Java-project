//write a program in java to print half pyramid while using while loop.
import java.util.Scanner;
class pattern
{
	public static void main(String [] args)
	{
		int i,j,rows;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number of Rows");
		rows=sc.nextInt();
		i=1;
		while(i<=rows)
		{
			j=1;
			while(j<=i)
			{
				System.out.print(j);
				j++;
			}
			System.out.println();
			i++;
		}
	}
}