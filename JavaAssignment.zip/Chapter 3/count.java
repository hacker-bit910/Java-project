//write a program in java to find the number of digits in given number.
import java.util.Scanner;
class count
{
	public static void main(String [] args)
	{
		int n,r=0;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number for count=");
		n=sc.nextInt();
		while(n!=0)
		{
			n=n/10;
			r=r+1;
		}
		System.out.println("Number of digits in the integer are::"+r);
	}
}