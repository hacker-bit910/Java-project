//Wap in java to print the sum of digit.
import java.util.Scanner;
class sum
{
	public static void main(String [] args)
	{
		int n,i,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number:");
		i=sc.nextInt();
		while(i>0)
		{
			n=i%10;
			sum=sum+n;
			i=i/10;
		}
		System.out.println("Sum of digit="+sum);
	}
}