//write a program in java to check whether a number is armstrong or not.
import java.util.Scanner;
class Armstrong
{
	public static void main(String [] args)
	{
		int n, num, rem;
		int res=0;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter any number for check=");
		n=sc.nextInt();
		num=n;
		while(num!=0)
		{
			rem=num%10;
			res=res+rem*rem*rem;
			num=num/10;
		}
		if(res==n)
		{
			System.out.println("Number is Armstrong");
		}
		else
		{
			System.out.println("Number is not Armstrong");
		}
	}
}