//Wap in java to print alphabet pattern.
class ralphabet
{
public static void main(String[] args)
  {
    int i, j, n = 5;
    for (i = n; i >= 1; i--)
    {
        for (j = 1; j <= i; j++)
        {
            System.out.printf("%c ", 'A' - 1 + i);
        }
        System.out.printf("\n");
    }
  }
}
 