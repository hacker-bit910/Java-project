//write a program in java to print digits in reverse number.
import java.util.Scanner;
class revers
{
	public static void main(String [] args)
	{
		int n,rem,rev=0;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter any for print Reverse=");
		n=sc.nextInt();
		while(n!=0)
		{
			rem=n%10;
			rev=rev*10+rem;
			n=n/10;
		}
		System.out.println("reversed Number="+rev);
	}
}