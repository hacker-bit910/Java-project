//Wap in java to find prime number by user input.
import java.util.Scanner;
class primecheck
{
   public static void main(String args[])
   {		
	int n,num,i;
	boolean isPrime=true;
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter any number:");
	//capture the input in an integer
	 num=sc.nextInt();
     
	for(i=2;i<=num/2;i++)
	{
           n=num%i;
	   if(n==0)
	   {
	      isPrime=false;
	      break;
	   }
	}
	//If isPrime is true then the number is prime else not
	if(isPrime)
	   System.out.println(num + " is a Prime Number");
	else
	   System.out.println(num + " is not a Prime Number");
   }
}