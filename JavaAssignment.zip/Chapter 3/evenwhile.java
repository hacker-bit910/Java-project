//Wap in java to find even number while using for loop.
import java.util.Scanner;
class evenwhile
{
     public static void main (String args[])
	 {
        int i=1,num;
         Scanner scan=new Scanner(System.in);
        //create a scanner object for input

         System.out.print("Print all even number until:\n ");


            num=scan.nextInt();//Reads input from user and stored in variable num
             System.out.print("Even number from 1 to "+num+" are: \n");

                  while(i<=num)
				{
				//loop for iterate from 1 to maximum
                  if(i%2==0)
				  {//using modular operator for finding even numbers
                  System.out.print(i+"\t");
                   }
				  i++;

                 }
       }
}