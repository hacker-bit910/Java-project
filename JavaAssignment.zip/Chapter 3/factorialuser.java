//Wap in Java to find factorial number by user input.
import java.util.Scanner;
class factorialuser
{

    public static void main(String[] args) 
	{

    	//We will find the factorial of this number
        int n;
        System.out.println("Enter the number: ");
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt();
        scanner.close();
        long fact = 1;
        int i = 1;
        while(i<=n)
        {
            fact = fact * i;
            i++;
        }
        System.out.println("Factorial of "+n+" is: "+fact);
    }
}