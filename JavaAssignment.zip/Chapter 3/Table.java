//wap in java to print table (2*1=2) while using for loop.
import java.util.Scanner;
class Table 
{
    public static void main(String[] args) 
    {
		int n,i;
        Scanner sc = new Scanner(System.in);
	    System.out.print("Enter number:");        
	    n=sc.nextInt();
        for(i=1; i <= 10; i++)
        {
            System.out.println(n+" * "+i+" = "+n*i);
        }
    }
}