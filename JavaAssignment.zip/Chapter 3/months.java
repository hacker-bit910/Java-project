//Wap in java to use Switch and find Months name.
/*final int NUMBER=0;
String line;
char letter;
Scanner statement;
line=sc.nextLine();
letter=line.CharAt(Number);
switch(letter)
*/
import java.util.*;
class months
{
	public static void main(String [] arr)
	{
		final int ONE=0;
		String line;
		char letter;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the character");
		line=sc.nextLine();
		letter=line.charAt(ONE);
		System.out.print("Display the name of Month=");
		switch(letter)
		{
			case 'A':
			case 'a':{			
			System.out.println("January");
			break;}
			case 'B':
			case 'b':{
			System.out.println("February");
			break;}
			case 'C':
			case 'c':{
			System.out.println("March");
			break;}
			case 'D':
			case 'd':{
			System.out.println("April");
			break;}
			case 'E':
			case 'e':{
			System.out.println("May");
			break;}
			case 'F':
			case 'f':{
			System.out.println("June");
			break;}
			case 'G':
			case 'g':{
			System.out.println("July");
			break;}
			case 'H':
			case 'h':{
			System.out.println("August");
			break;}
			case 'I':
			case 'i':{
			System.out.println("September");
			break;}
			case 'J':
			case 'j':{
			System.out.println("October");
			break;}
			case 'K':
			case 'k':{
			System.out.println("November");
			break;}
			case 'L':
			case 'l':{
			System.out.println("December");
			break;}
			default:
			{
				System.out.print("Enter valid character");
			}
		}		
	}
}