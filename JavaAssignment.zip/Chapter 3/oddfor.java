//Wap in java to find even odd number while using for loop.
import java.util.Scanner;
class oddfor
{
     public static void main (String args[])
	 {
        int i,num;
         Scanner scan=new Scanner(System.in);
        //create a scanner object for input

         System.out.print("Print all odd number until:\n ");


            num=scan.nextInt();//Reads input from user and stored in variable num
             System.out.print("Odd number from 1 to "+num+" are: \n");

                  for(i=1; i<=num; i++)
				{
				//loop for iterate from 1 to maximum
                  if(i%2!=0)
				  {//using modular operator for finding odd numbers
                  System.out.print(i+"\t");
                   }

                 }
       }
}