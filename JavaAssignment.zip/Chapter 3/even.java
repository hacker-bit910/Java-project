//Wap in Java to Find Even Odd.
import java.util.*;
class even
{
	public static void main(String [] arr)
	{
		int a;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number:");
		a=sc.nextInt();
		if(a%2==0)
		{
			System.out.println("Even Number");
		}
		else
		{
			System.out.println("Odd Number");
		}
		
		
	}
}