
//wap in java to add two number 
import java.util.Scanner;

class add {
    public static void main(String[] arr) {
        int x,y;
        float z;
        Scanner s1 = new Scanner(System.in);
        System.out.println("Enter any two number");
		x=s1.nextInt();
		y=s1.nextInt();
        z = x + y;
        System.out.print("devide of  =" + z);
    }
}
