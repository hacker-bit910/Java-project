
//Wap in java to print arithmetic
import java.util.*;

class Arithmetic {
	public static void main(String args[]) {
		int a, b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any Two number which want to arithmetic Operation");
		a = sc.nextInt();
		b = sc.nextInt();
		System.out.println("Adding of two number a+b=" + (a + b));
		System.out.println("Subtraction of two number a-b=" + (a - b));
		System.out.println("Multiplication of two number a*b=" + (a * b));
		System.out.println("Division of two number a/b=" + (a / b));
		System.out.println("Modulas of two number a%b=" + (a % b));

	}
}