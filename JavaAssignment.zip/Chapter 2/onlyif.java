// Wap in java to use of If Statement.
import java.util.*;
class onlyif
{
	public static void main(String [] arr)
	{
		int a,b;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter of value a and b:");
		a=sc.nextInt();
		b=sc.nextInt();
		if(a>b)
		{
			System.out.println("a greater than b");
		}
		else
		{
			System.out.println("b is greater than a");
		}
		
	}
}