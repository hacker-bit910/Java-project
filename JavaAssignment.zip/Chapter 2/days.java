//Wap in java to use Switch and find week name.
import java.util.*;
class days
{
	public static void main(String [] arr)
	{
		int c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number for days");
		c=sc.nextInt();
		System.out.println("Display the name of week days"+c);
		switch(c)
		{
			case 1:
			System.out.println("Monday");
			break;
			case 2:
			System.out.println("Tuesday");
			break;
			case 3:
			System.out.println("Wednesday");
			break;
			case 4:
			System.out.println("Thursday");
			break;
			case 5:
			System.out.println("Friday");
			break;
			case 6:
			System.out.println("Satuerday");
			break;
			case 7:
			System.out.println("Sunday");
			break;
		}		
	}
}