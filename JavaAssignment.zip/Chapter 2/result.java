//Wap in java to use of Switch Statement Get Result.
import java.util.*;
class result
{
	public static void main(String [] arr)
	{
		int mark, a, x;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number for select case");
		x=sc.nextInt();
		System.out.println("This is your Select program"+x);
		switch(x)
		{
			case 1:
			System.out.println("Enter marks for result:");
			mark=sc.nextInt();
			if(mark>=43)
			{
				System.out.println("Result=PASS");
			}
			else
			{
				System.out.println("Result= FAIL");
			}
			break;
			
			case 2:
			System.out.println("Enter any Number");
			a=sc.nextInt();
			if(a>0)
			{
				System.out.println("Positive Num");
			}
			else if(a<0)
			{
				System.out.println("Negative Num");
			}
			else
			{
				System.out.println("Zero");
			}
			break;
			default:
			System.out.println("Enter Valid Number");
		}
	}
}