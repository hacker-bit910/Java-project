//Wap in java to swap two value using temp variable.
import java.util.Scanner;
class Swap2
{
	public static void main(String [] args)
	{
		int x,y,z; // x and y are to swap
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter the value of x and y");
		x=sc.nextInt();
		y=sc.nextInt();
		System.out.println("before swapping numbers:"+x+" "+y);
		//Swapping
		z=x;
		x=y;
		y=z;
		System.out.println("After Swapping:"+x+" "+y);
	}
}
