//write a program in java to check whether a number is palindrome or not.
import java.util.Scanner;
class palindrome
{
	public static void main(String [] args)
	{
		int n;
		int r,sum=0, num;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter any number to check=");
		n=sc.nextInt();
		num=n;
		while(n>0)
		{
			r=n%10; //getting remainder
			sum=(sum*10)+r;
			n=n/10;
		}
		if(num==sum)
		{
			System.out.println("Number is palindrome");
		}
		else
		{
			System.out.println("Number is not palindrome");
		}
	}
}