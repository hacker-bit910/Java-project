//Java Program to demonstrate the use of Nested IfElse Statement.
  import java.util.*;
class NestedIf
 {    
public static void main(String[] args)
  { 
    int age, weight;    
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter donater age:");
    age=sc.nextInt();
    System.out.println("Enter donater weight");	
	weight=sc.nextInt();
    if(age>=19)
	{    
        if(weight>60)
		{  
            System.out.println("You are eligible to donate blood");  
        }    
    }
    else
	{
		System.out.println("You are not eligible to donate blood");
	}		
  }
}  