//Wap in java to use of Else If Statement.
import java.util.*;
class elseif
{
	public static void main(String [] arr)
	{
		final int ONE=0;
		String line;
		char ch;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the character");
		line=sc.nextLine();
		ch=line.charAt(ONE);
        if(ch=='d'||'D')		
		{
			System.out.println("Deepak is a smart boy");
		}
		else if(ch=='s'||'S')
		{
			System.out.println("Sakshi is a claver girl");
		}
		else if(ch=='r'||'R')
		{
			System.out.println("Rinku is a honest boy");
		}
		else
		{
		   System.out.println("Enter valid character");	
		}
	}
}
