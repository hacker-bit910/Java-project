class instance
{
    int x=40;  // instance variable
  public static void main(String args[])
{
   int y=10;    // local variable 
int z=20;   // access without object in program 

instance in=new instance(); // object create
System.out.println("value of x="+in.x);

System.out.println("value of y="+y);
System.out.println("value of z="+z);



}

}