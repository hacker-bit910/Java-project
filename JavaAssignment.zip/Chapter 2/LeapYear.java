//Wap in java to Find leap year while using if else statement.
import java.util.*;
class LeapYear
{    
public static void main(String[] args)
{    
    int year;   
    Scanner sc=new Scanner(System.in);	
    System.out.print("Enter any year=");
    year=sc.nextInt();
    if(((year % 4 ==0) && (year % 100 !=0)) || (year % 400==0))
	{		
        System.out.println("LEAP YEAR");  
    }  
    else
	{  
        System.out.println("COMMON YEAR");  
    }  
}    
}    