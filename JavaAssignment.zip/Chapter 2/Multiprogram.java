//Wap in java to use of Switch Statement and use Arithmetic and find profit loss,compound Interest and division.
import java.util.*;
class Multiprogram
{
	public static void main(String [] arr)
	{
		int x,a,b,ans;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number for select case");
		x=sc.nextInt();
		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println("This is your Select program"+x);
		switch(x)
		{
		case 1:
		    System.out.println("\nEnter a value"+a);
		    System.out.println("\nEnter b value"+b);
		    System.out.println("Adding of two number a+b="+(a+b));
			System.out.println("Subtraction of two number a-b="+(a-b));
			System.out.println("Multiplication of two number a*b="+(a*b));
			System.out.println("Division of two number a/b="+(a/b));
			System.out.println("Modulas of two number a%b="+(a%b));
			break;
		
		case 2:
		    System.out.println("Enter a value"+a);
		    System.out.println("Enter b value"+b);
			if(a>b)
        {
            ans=a-b;
            System.out.println("Profit:"+ans);
        }
        else if(a<b)
        {
            ans=b-a;
            System.out.println("Loss:"+ans);
        }
        else
            System.out.println("No profit or loss");
		    break;
		}
	}
}