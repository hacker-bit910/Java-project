//Wap in java to add Array.
public class Arraysum {
    public static void main(String[] args) {
        int a[] = { 34, 67, 78, 65, 45, 78, 89 };
        int size = a.length;
        int i, sum = 0;
        System.out.println("Size of the given array=" + size);
        System.out.println("Display the array element");
        for (i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
        // Sum of array element
        for (i = 0; i < a.length; i++) {
            sum = sum + a[i];
        }
        System.out.println("sum of array elements sum=" + sum);
    }
}
