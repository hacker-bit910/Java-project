//Wap in java to find last element in Array.
public class Arraylast {
    public static void main(String[] args) {
        int a[] = { 34, 67, 78, 65, 45, 78, 89 };
        int size = a.length;
        int i, sum = 0;
        System.out.println("Size of the given array=" + size);
        System.out.println("Display the array element");
        for (i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
        // Get last element in given array
        int last = a[a.length - 1];
        System.out.println("Get last element of the array=" + last);
    }
}