//Wap in java to calculate discount of product
//Formula discount=listprice*discount;
import java.lang.*;
import java.util.*;
class Discount
{
	public static void main(String [] arr)
	{
		//create an object
		Scanner sc=new Scanner(System.in);
		double dis,amt,mp,s;
		System.out.print("Enter marketprize");
		mp=sc.nextDouble();
		System.out.print("Enter Discount");
		dis=sc.nextDouble();
		s=100-dis;
		amt=(s*mp)/100;
		System.out.println("Amount after discount"+amt);
	}
}