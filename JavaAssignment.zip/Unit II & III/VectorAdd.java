//Wap in java to use v1ector.
import java.util.*;
class VectorAdd
{
	public static void main(String [] args)
	{
		Vector<String> v1=new Vector<>();
		//Add string in v1ector
		v1.add("Window 95");
		v1.add("Window XP");
		v1.add("Window 2007");
		v1.add("Window 8");
		v1.add("Window 8.1");
		v1.add("Window 10");
		v1.add("Window 11");
		v1.add("Kali Linux");
		v1.add("Obantu");
		System.out.println("\nvector="+v1);
		//Access element from the v1ector using get() method
		String s=v1.get(1);
		System.out.println("\nAccess first element of the vector:"+s);
		
		//remov1e element from vector arra
		String st=v1.remove(2);
		System.out.println("\nremove index "+st+"    "+st);
		System.out.println("\nNew vector list after remove the element:"+v1);
		//clear all element from v1ector
		v1.clear();
		System.out.println("clear vector:"+v1);
		
	}
}