//Wap in Java to find Torque=((2m1m2)/(m1+m2))*g
import java.util.*;
import java.lang.*;
class Torque
{
	public static void main(String [] arr)
	{
		float m1,m2,g,t;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the value of M1=");
		m1=sc.nextFloat();
		System.out.print("Enter the value of M2=");
		m2=sc.nextFloat();
		System.out.print("Enter the value of G=");
		g=sc.nextFloat();
		t=((2*m1*m2)/(m1+m2))*g;
		System.out.println("The Torque value is="+t);
		
	}
}