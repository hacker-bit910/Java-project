//Wap in java to print 2d array.
import java.util.*;
class Array2d
{
	final static int i=3;
	final static int j=4;
	public static void main(String [] args)
	{
		int table[][]=new int[i][j];
		int n,m;
		System.out.println("Multiplication Table");
		for(m=1;m<i;m++)
		{
			for(n=1;n<4;n++)
			{
				table[m][n]=m*n;
				System.out.println(""+table[m][n]);
			}
			System.out.println("");
		}
	}
}