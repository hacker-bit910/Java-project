//Wap in java to add Array.
public class Arraysort 
{
    public static void main(String[] args) 
    {
        int a[] = { 34, 67, 76, 65, 45, 78, 89 };
        int size = a.length;
        int i, sum = 0;
        System.out.println("Size of the given array=" + size);
        System.out.println("Display the array element");
        for (i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
        // Decrease Order
        for (i = 0; i < a.length; i++) 
        {
            for (int j = i + 1; j < a.length; j++) 
            {
                if (a[i] < a[j]) 
                {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
            System.out.println("Sorted Array");
         for (i = 0; i < a.length; i++) 
        {
            System.out.println("" + a[i]);
        }
            System.out.println("");
    }
}

