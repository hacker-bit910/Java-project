import java.util.Scanner;
class celsius
{
	public static void main(String [] args)
	{
		float c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Fahreheit Temperature:");
		c=sc.nextfloat();
		System.out.println("Celsius temperature is ="+celsius(c));
	}
	static double celsius(float f)
	{
		return (f-32)*5/9;
	}
}