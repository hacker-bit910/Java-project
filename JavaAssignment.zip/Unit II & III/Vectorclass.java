//Wap in java to use vector.
/*vector is a class it's avaiable in java.util package.
this class can be used to create a generic dyanamic array known as vector that can be hold object of any typeand any number.
but vector contained any type of data.(Not homoginious)


1.vector intVector=new Vector();//declared without size
2.vector list=new Vector(3);//declared with size


Call Methods.----->
1. list.addElement(item)---------end of the list.
2. lisr.elementAt(10)
3. list.size()---------to find the size of list
4. list.removeElement(item)---------remove the item for list.
5. list.removeElementAt(n)
6. list.removeAllElements()
7.list.copyInto(array)---copy all item from the list.
8. list.insertElementAt(item,n)------insert the item at the nth position.
*/
import java.util.*;
class Vectorclass
{
	public static void main(String[] ar)
	{
		Vector list=new Vector();
		int x=ar.length;
		for(int i=0; i<x; i++)
		{
			list.addElement(ar[i]);
			
		}
		list.insertElementAt("Deepak Pandat",2);
		int size=list.size();
		String listArray[]=new String[size];
		list.copyInto(listArray);
		System.out.println("List of langauge");
		for(i=0; i<size; i++)
		{
			System.out.println(listArray[i]);
		}
			
	}
}