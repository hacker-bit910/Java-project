//Wap in java to find first element in array.
public class Arrayfirst {
    public static void main(String[] args) {
        int a[] = { 34, 67, 78, 65, 45, 78, 89 };
        int size = a.length;
        int i, sum = 0;
        System.out.println("Size of the given array=" + size);
        System.out.println("Display the array element");
        for (i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
        // get the first elements of the given array
        int first = a[0];
        System.out.println("First element of array=" + first);
    }
}
