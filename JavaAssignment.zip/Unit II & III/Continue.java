
//Wap in java to add amount in atm machine.
import java.util.*;
import java.lang.*;

class Continue {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		final int ONE = 0;
		String line;
		double money, umoney;
		System.out.print("How much money do you want to Credit? ");
		money = sc.nextDouble();
		System.out.println("Ok, here is yours $" + money);
		char c;
		sc.nextLine();
		System.out.println("Do you want to continue y or n");
		line = sc.nextLine();
		c = line.charAt(ONE);
		switch (c) {
			case 'y':
			case 'Y': {
				System.out.println("Do you want to add more amount");
				umoney = sc.nextDouble();
				money += umoney;
				System.out.println("Update Statement here is your $" + money);
				break;
			}
			case 'n':
			case 'N': {
				System.out.println("Thank you for giving your time");
				break;
			}
			default: {
				System.out.println("Please Enter valid Option");
			}
		}
	}
}