//Wap in java to find Area=πrᶺ2+2πrh
import java.util.*;
import java.lang.*;
class Area
{
	public static void main(String [] arr)
	{
		float r,h,area;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the value of R=");
		r=sc.nextFloat();
		System.out.print("Enter the value of H=");
		h=sc.nextFloat();
		area=(2*22*(r+h))/7;
		System.out.println("The value of Area="+area);
	}
}