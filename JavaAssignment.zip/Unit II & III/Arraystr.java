//Wap in java to find string in array.
/*
string ab="Sunil kumar"
length=11
int x=ab.length();
How to declared and definition of string array.
String student;
students=new sting("S.K Singh");
String students=new String("S.K Singh");
int x=student.length();
String fullName=first name+ Second name;
String city="Tamil"+"Nadu";
char ab[]=new char[4];
s1=s2;
String s2="SK SINGH";
s1=s2.toLowerCase;
s1=s2.toUpperCase;
s1.equal(s2);
s1.concat(s2);
s1=s2.replace('x','y')
*/
class Arraystr
{
	public static void main(String []args)
	{
		String name[]={"Mathura", "Aligarh", "Noida", "New Delhi"};
		int x=name.length;
		for(int i=0; i<x;i++)
		{
			for(int j=i+1; j<x; j++)
			{
				if(name[j].compareTo(name[i])<0)
				{
					String temp=name[i];
					name[i]=name[j];
					name[j]=temp;
				}
			}
			for(i=0; i<x;i++)
			{
			   System.out.println(""+name[i]);
			}
		}
	}
}