
//Wap in java to find array.
import java.util.*;

class Array2 {
    public static void main(String[] args) {
        int a[] = new int[7];
        int size = a.length;
        int i;
        Scanner sc = new Scanner(System.in);
        for (i = 0; i < a.length; i++) {
            System.out.println("Enter the Index " + i + "value=");
            a[i] = sc.nextInt();
        }
        System.out.println("Size of the given array=" + size);
        System.out.println("Display the array element");
        for (i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }

    }
}