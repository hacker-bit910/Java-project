//Wap in to evaluate the following condition
import java.util.*;
import java.lang.Math;
class energy
{
	public static void main(String [] arr)
	{
		double eng;
		float mass,acce,height,velo;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of mass");
		mass=sc.nextFloat();
		System.out.println("Enter the value of Acceleration");
		acce=sc.nextFloat();
		System.out.println("Enter the value of Height");
		height=sc.nextFloat();
		System.out.println("Enter the value of velocity");
		velo=sc.nextFloat();
		System.out.println("The value of Energy=");
		eng=mass*(acce*height+(Math.pow(velo,2)));
		System.out.println("eng="+eng);
		System.out.println(String.format("%.2f",eng));
	}
}