
//Wap in java to use array.
import java.util.*;

class array {
    public static void main(String[] args) {
        int a[] = new int[5];
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < a.length; i++)
            System.out.println("Enter the Index " + i + "value=");
        a[i] = sc.nextInt();
        System.out.println("Display the array element");
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[5]);
        }
    }
}